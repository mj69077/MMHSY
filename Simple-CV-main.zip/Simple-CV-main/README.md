# Simple-CV
It is just simple cv I build it to train myself in css.
